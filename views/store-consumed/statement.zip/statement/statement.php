<?php

use app\models\StoreConsumed;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use kartik\export\ExportMenu;
/** @var yii\web\View $this */
/** @var app\models\Search\StoreConsumed $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Store Statement';
$this->params['breadcrumbs'][] = $this->title;
//echo "<pre>";print_r( $products );die();
$columns[] = ['class' => 'yii\grid\SerialColumn'];
$columns[] = [
                'header'=>'Date',
                'content'=>function($model){
                    if( isset( $model->invoice_date ) ){
                        return $model->invoice_date;
                    }else{
                        return $model->date;
                    }
                }
            ];
            
foreach( $products as $product_id => $product_name ){
    $columns[] = [
        'header'=> $product_name,
        'content' => function( $model ) use ($product_id){
            if( isset( $model->invoice_date ) ){
                return $model->getConsumedProductQuantity( $product_id );
            }else{
                return $model->getIssueProductQuantity( $product_id );
            }
        }
    ];
}
?>
<div class="store-consumed-index box box-primary"> 
    <div class="box-header with-border">
        <?=$this->render('_search', ['model' => $searchModel]); 
        echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $columns,
    'clearBuffers' => true, //optional
]);
        ?>
        <div class="box-body">
            <?php if( $searchModel->site ):?>
                <div class="row">
                    <div class="col-sm-3"><label>State:</label><?= $searchModel->state->state?></div>
                    <div class="col-sm-3"><label>District:</label><?= $searchModel->district->district?></div>
                    <div class="col-sm-6"><label>Billing Company:</label><?= $searchModel->billingCompany->name?></div>
                </div>
                <div class="row">
                    <div class="col-sm-8"><label>Agreement:</label><?= $searchModel->agreement->agreement_no?></div>
                    <div class="col-sm-4"><label>Site:</label><?= $searchModel->site->name?></div>
                </div>
            <?php endif;?>
            
                <?=
                     GridView::widget([
                    'dataProvider' => $dataProvider,
                    //'filterModel' => $searchModel,
                    'columns' => $columns,
                ]); 
                ?>
        </div>
    </div>
</div>
